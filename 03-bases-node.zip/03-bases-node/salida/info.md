#informacion
contiene el prod. final de la aplicacion